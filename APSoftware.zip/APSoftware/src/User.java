/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Patel
 */
public class User {
    private String EmployeeID, LineStatus, UnitProduced, UnitTarget,HourStarted,HourEnded,TotalHours,Shift,Crew;
    
    public User(String EmpID, String LineStat,String UnitProduced,String UnitTarget,String HourStarted, String HourEnded, String TotalHours, String Shift, String Crew){
        this.EmployeeID = EmpID;
        this.LineStatus = LineStat;
        this.UnitProduced = UnitProduced;
        this.UnitTarget = UnitTarget;
        this.HourStarted = HourStarted;
        this.HourEnded = HourEnded;
        this.TotalHours = TotalHours;
        this.Shift = Shift;
        this.Crew = Crew;
       
        
    }
    public String getEmpID(){
        return EmployeeID;
    
}
     public String getLineStatus(){
        return LineStatus;
    
}
     public String getUnitProduced(){
        return UnitProduced;
    
}
     public String getUnitTarget(){
        return UnitTarget;
    
}
     public String getHourStarted(){
        return HourStarted;
    
}
     public String getHourEnded() {
         return HourEnded;
     }
     public String getTotalHours(){
        return TotalHours;
    
}
     public String getShift(){
        return Shift;
    
}
     public String getCrew(){
        return Crew;
    
}
     
}
